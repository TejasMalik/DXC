package com.dxc.assess.client;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UsersApp users = new UsersApp();
		users.validate();
	}

}
