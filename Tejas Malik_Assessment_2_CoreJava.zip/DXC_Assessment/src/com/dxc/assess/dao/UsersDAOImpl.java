package com.dxc.assess.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.dxc.assess.jdbc.DBConnection;
import com.dxc.assess.model.Users;

public class UsersDAOImpl implements UsersDAO {

	private static final String FETCH_ALL_TRAINING_DETAILS = "SELECT * FROM training";

	private static final String VALIDATE_DETAILS = "SELECT * FROM users WHERE username = ? AND password = ?";

	Connection connection = DBConnection.getConnection();

	public boolean userValidate(Users user) {

		try {
			PreparedStatement stat = connection.prepareStatement(VALIDATE_DETAILS);

			stat.setString(1, user.getUserName());
			stat.setString(2, user.getPassWord());

			ResultSet results = stat.executeQuery();

			if (results.next()) {

				System.out.println("User successfully authenticated.");
				System.out.println("Welcome...");
				return true;

			} else {
				System.out.println("User name cannot be authenticated.");
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}

	public void getAllTrainingDetails() {

		try {
			Statement stat = connection.createStatement();
			ResultSet res = stat.executeQuery(FETCH_ALL_TRAINING_DETAILS);

			while (res.next()) {

				System.out.println(res.getInt(1));
				System.out.println(res.getString(2));
				System.out.println(res.getString(3));
				System.out.println(res.getInt(4));
				System.out.println("*************************************************");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void updatePercentage() {

		Scanner s = new Scanner(System.in);

		try {
			Statement stat = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);

			ResultSet res = stat.executeQuery("select * from training");
			ResultSetMetaData rsmd = res.getMetaData();

			while (res.next()) {
				System.out.println(res.getInt(1));
				System.out.println(res.getString(2));
				System.out.println(res.getString(3));

				if (res.getInt(4) > 0) {
					System.out.println("Percentage already Entered.");
				} else {
					System.out.println("Enter the Percentage: ");
					int percent = s.nextInt();

					res.updateInt(4, percent);
					res.updateRow();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
