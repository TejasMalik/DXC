module.exports = function (app) {
    var fs = require('fs')
    var filedata = fs.readFileSync("./resources/about.txt", "utf8")

    app.get('/', function (request, response) {
       

        response.send("<h1>Welcome to HomePage, write /about to get to read about.txt<h1>")
    })

    app.get('/about', function (request, response) {


        response.render('about', { data: filedata })
    })
}