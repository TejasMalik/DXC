var express = require("express");
var app = express();
var todoController = require("./controllers/aboutController");


//set up template engine
app.set("view engine", "ejs");

todoController(app)

//listen to port
app.listen(3000);
console.log("You are listening to port 3000");
