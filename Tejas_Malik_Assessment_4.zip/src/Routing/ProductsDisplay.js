import React, { Component } from 'react';

class ProductsDisplay extends Component {
    render() {
        const { product } = this.props

        return (
            <div>
                <h3>
                    <br></br>
                    Product Id: {product.productId}<br></br>
                    Quantity:  {product.quantity}<hr></hr>
                </h3>
            </div>
        );
    }
}

export default ProductsDisplay;