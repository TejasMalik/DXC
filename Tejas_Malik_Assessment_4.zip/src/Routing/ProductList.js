import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductsDisplay from './ProductsDisplay';
import ProductDetails from './ProductDetails'

class ProductList extends Component {
    
    render() {
        const productList = [
            {
                productId: 1001,
                quantity: 20,

            },
            {
                productId: 1002,
                quantity: 29,
            },
            {
                productId: 1003,
                quantity: 50,
            },
            {
                productId: 1004,
                quantity: 10,
            },

            {
                productId: 1005,
                quantity: 35,
            },
        ]
        return (
            <div>
                {productList.map((product, index) =>
                    <Link to={`${this.props.match.url}/` + product.productId}>
                        <ProductsDisplay render={({ match }) => match = { match }}
                            nn={index}
                            key={index}
                            product={product}
                        ></ProductsDisplay>
                    </Link>

                )}

                <Route path={`${this.props.match.path}/:productId`}
                    render={({ match }) => match = { match }}
                    component={ProductDetails} />
            </div>

        );
    }
}
export default ProductList;
