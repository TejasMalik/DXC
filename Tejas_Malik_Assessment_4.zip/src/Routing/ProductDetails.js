import React, { Component } from 'react';
import ProductList from './ProductList';

class ProductDetails extends Component {

    constructor(props) {
        super(props);
        this.state = ({
            quant: '',
            errors: {
                quant: ''
            },
            
        })
        this.doValidation = this.doValidation.bind(this)
        this.updateQuantity = this.updateQuantity.bind(this)
    }

    doValidation = (e) => {
        e.preventDefault()
        const { name, value } = e.target;
        let errors = this.state.errors;

        switch (name) {
            case 'quant':
                errors.quant = value.length === 0  ? 'Quantity must be not be Zero' : ''
                break;
            case 'quant':
                errors.quant = parseInt(value) < 0 ? 'Quantity cannot be negative' : ''
                break;
            default:
                break;
        }

        this.setState({
            errors, [name]: value
        })
    }

    updateQuantity(e) {
        var quanti = this._inputQuantity.value
        console.log(quanti)
        e.preventDefault()
        
    }


    render() {
        return (
            <div>
                Your product details comes here
                You have clicked on :  {this.props.match.params.productId}
                <form onSubmit={this.updateQuantity}>
                    Product Id: &nbsp; <input type="text" ref={(a) => this._inputElement = a} value={this.props.match.params.productId} disabled></input>
                    <br></br>
                    Quantity: &nbsp; &nbsp; &nbsp;<input type="text" ref={(a) => this._inputQuantity = a} onChange={this.doValidation}></input>
                    <br></br>
                    <span className="error">{this.state.errors.quant}</span>
                    <br></br>
                    <input type='submit' value="Update"></input>

                </form>
            </div>
        );
    }
}

export default ProductDetails;