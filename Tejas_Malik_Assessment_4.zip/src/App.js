import React from 'react';

import './App.css';



function App() {
  return (
    <div className="App">
      <a href="Home">Home</a>|
      <a href="ProductDetails">Product Details Update</a>

      <hr></hr>
      <h1>Welcome Page</h1>
    </div>
  );
}

export default App;
